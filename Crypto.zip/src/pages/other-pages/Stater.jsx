import { PageBreadcrumb } from '@/components'
const Stater = () => {
	return <PageBreadcrumb title="Starter" subName="Pages" />
}
export default Stater
