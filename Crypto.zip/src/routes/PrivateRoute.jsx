import React from 'react'
const PrivateRoute = ({ component: RouteComponent }) => {
	return <RouteComponent />
}
export default PrivateRoute
