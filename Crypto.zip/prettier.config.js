const config = {
  bracketSpacing: true,
  semi: false,
  singleQuote: true,
  trailingComma: "es5",
  useTabs: true,
  tabWidth:2,
  arrowParens:"always",
  jsxBracketSameLine:true,
};
export default config;