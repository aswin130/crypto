1. Status Type = TODO | WIP | DONE

## Todo

| Status | Problem                                                     | Solution                  | Assigned |
| ------ | ----------------------------------------------------------- | ------------------------- | -------- |
| DONE   | Top loading bar                                             |                           | ABHINAY  |
| DONE   | Splash Screen                                               |                           | ABHINAY  |
| DONE   | Image Upload validation not working                         | shouldValidate            | KENIL    |
| DONE   | Left side menu with data and array.map                      |                           | AJAY     |
| DONE   | Authentication and protected routes                         |                           | AJAY     |
| DONE   | Active menuItemWithChildren items                           |                           | ABHINAY  |
| DONE   | ui/elements/progress==>Vertical ProgressBar not working     |                           |          |
| DONE   | ui/advanced/sweetAlert==>Custom animation  not working      | use lib animate.css       |          |
| DONE   | ui/advanced/sweetAlert==>Declarative template  not working  |                           |          |
| DONE   | ui/advanced/range-slider==>not working                      |                           |          |
| DONE   | ui/charts/Toast==>color theme issue                         |                           |          |
| DONE   | dashboards/crypto==> BitcoinPriceAndVolume ==> not working  |                           |          |
| DONE   | dashboards/crypto==> CurrencyCalculator ==> not working     |                           |          |
| DONE   | dashboards/project==> Calendar ==> not working              | use lib lite calendar     |          |
| DONE   | apps/customers==> customersDetail ==> not working           | use lib react-tabulator   |          |
| DONE   | apps/projects/KanbanBoard==> strictMode==> not working      | use lib @hello-pangea/dnd |          |
| DONE   | apps/ecommerce/checkout ==> Billing Details ==>design issue |                           |          |
| DONE   | uiKit/charts/justGage ==> Random Refresh not working        |                           |          |
| DONE   | components/tables ==> TypeScript issue                      |                           | KENIL    |
| TODO   | maps/VectorMap ==> Map Load Issue                           |                           | KENIL    |
