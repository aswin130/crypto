const colorVariants = [
	'primary',
	'secondary',
	'success',
	'warning',
	'info',
	'danger',
	'dark',
]
const extendedColorVariants = [
	'primary',
	'secondary',
	'success',
	'info',
	'warning',
	'danger',
	'dark',
	'purple',
	'pink',
]
export { colorVariants, extendedColorVariants }
