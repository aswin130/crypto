const Preloader = () => (
	<div className="preloader-progress-bar">
		<div className="progress-value"></div>
	</div>
)
export default Preloader
